import { useEffect } from 'react';

/** المان‌های .reveal-item را هنگام ورود به صفحه نمایش می‌دهد. با reduced-motion بلافاصله نشان می‌دهد. */
export function useScrollReveal() {
  useEffect(() => {
    const elements = document.querySelectorAll('.reveal-item');
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !('IntersectionObserver' in window)) {
      elements.forEach((el) => el.classList.add('visible'));
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}
