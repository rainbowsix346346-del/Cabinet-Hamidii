export const HERO_IMAGE = {
  src: 'https://images.unsplash.com/photo-1565538810643-b5bdb714032a?auto=format&fit=crop&w=900&q=80',
  alt: 'طرح الهام‌بخش کابینت آشپزخانه',
};

// آیتم اول = کارت بزرگ (featured)
export const INSPIRATION_ITEMS = [
  { id: 'i1', title: 'کابینت مدرن مینیمال', desc: 'ترکیب روکش مات با چوب طبیعی و خطوط ساده', img: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=80' },
  { id: 'i2', title: 'طراحی نئوکلاسیک گرم', desc: 'رنگ‌آمیزی خنثی با جزئیات ظریف ابزارخورده', img: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=800&q=80' },
  { id: 'i3', title: 'کمد دیواری یکپارچه', desc: 'تقسیم‌بندی کاربردی با حداکثر بهره‌برداری از ارتفاع', img: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=800&q=80' },
  { id: 'i4', title: 'جزیره آشپزخانه کاربردی', desc: 'فضای سینک و میز صبحانه‌خوری توکار', img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80' },
];
