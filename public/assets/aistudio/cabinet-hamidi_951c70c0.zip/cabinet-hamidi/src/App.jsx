import { useCallback, useState } from 'react';
import { BUSINESS_CONFIG } from './config/business.js';
import { buildTelHref } from './utils/tel.js';
import { useScrollReveal } from './hooks/useScrollReveal.js';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Services from './components/Services.jsx';
import Inspiration from './components/Inspiration.jsx';
import Steps from './components/Steps.jsx';
import EstimateForm from './components/EstimateForm.jsx';
import Faq from './components/Faq.jsx';
import Footer from './components/Footer.jsx';
import NoticeModal from './components/NoticeModal.jsx';

/** فقط اجزا را کنار هم می‌چیند و state سراسری حداقلی دارد. */
export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);

  useScrollReveal();

  const closeMenu = useCallback(() => setMenuOpen(false), []);
  const toggleMenu = useCallback(() => setMenuOpen((v) => !v), []);
  const closeNotice = useCallback(() => setNoticeOpen(false), []);

  const handlePhoneAction = useCallback(() => {
    const href = BUSINESS_CONFIG.hasConfiguredPhone ? buildTelHref(BUSINESS_CONFIG.phoneTel) : null;
    if (!href) { setNoticeOpen(true); return; }
    window.location.href = href;
  }, []);

  return (
    <div className="hamidi-site">
      <Header menuOpen={menuOpen} onToggleMenu={toggleMenu} onCloseMenu={closeMenu} />
      <main>
        <Hero onPhoneAction={handlePhoneAction} />
        <Services />
        <Inspiration />
        <Steps />
        <section id="estimate" className="bottom-section">
          <div className="container bottom-grid">
            <EstimateForm />
            <Faq />
          </div>
        </section>
      </main>
      <Footer />
      <NoticeModal isOpen={noticeOpen} onClose={closeNotice} />
    </div>
  );
}
