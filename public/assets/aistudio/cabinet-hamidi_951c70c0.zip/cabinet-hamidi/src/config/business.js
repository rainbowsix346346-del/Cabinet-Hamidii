/**
 * اطلاعات کسب‌وکار. وقتی شماره واقعی آماده شد:
 * phoneDisplay = '۰۶۱-۱۲۳۴۵۶۷۸'، phoneTel = '+98611234567'، hasConfiguredPhone = true
 */
export const BUSINESS_CONFIG = {
  brandName: 'کابینت حمیدی',
  city: 'اهواز',
  phoneDisplay: 'در حال تکمیل اطلاعات تماس',
  phoneTel: '',
  hasConfiguredPhone: false,
};

/** آدرس بک‌اند فرم. تا وقتی خالیه، فرم فقط شبیه‌سازی می‌شه. */
export const FORM_ENDPOINT = '';
export const FORM_TIMEOUT_MS = 10000;
export const FORM_COOLDOWN_MS = 30000;
