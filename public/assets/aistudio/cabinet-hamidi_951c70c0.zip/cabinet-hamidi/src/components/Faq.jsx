import { useState } from 'react';
import { FAQ_ITEMS } from '../data/faq.js';

/** سوالات متداول (آکاردئون). state داخلی خودش را دارد. */
export default function Faq() {
  const [openIndex, setOpenIndex] = useState(null);
  return (
    <div className="reveal-item">
      <div className="sec-label">سوالات رایج</div>
      <h3 className="block-title">پرسش‌های متداول مشتریان</h3>
      <div className="faq-wrap">
        {FAQ_ITEMS.map((item, idx) => {
          const open = openIndex === idx;
          return (
            <div key={item.q} className="faq-item">
              <h4 className="faq-heading">
                <button
                  type="button"
                  id={`faq-q-${idx}`}
                  className="faq-question"
                  aria-expanded={open}
                  aria-controls={`faq-a-${idx}`}
                  onClick={() => setOpenIndex(open ? null : idx)}
                >
                  <span>{item.q}</span>
                  <span aria-hidden="true">{open ? '−' : '+'}</span>
                </button>
              </h4>
              {open && (
                <div id={`faq-a-${idx}`} role="region" aria-labelledby={`faq-q-${idx}`} className="faq-answer">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
