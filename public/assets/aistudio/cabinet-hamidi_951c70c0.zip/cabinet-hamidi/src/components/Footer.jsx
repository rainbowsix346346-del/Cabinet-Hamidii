import { BUSINESS_CONFIG } from '../config/business.js';

/** فوتر سایت. */
export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-inner">
        <div>
          <strong>{BUSINESS_CONFIG.brandName}</strong> — اجرای سفارشی کابینت و سازه‌های ام‌دی‌اف در اهواز و خوزستان
        </div>
        <div>{BUSINESS_CONFIG.phoneDisplay}</div>
      </div>
    </footer>
  );
}
