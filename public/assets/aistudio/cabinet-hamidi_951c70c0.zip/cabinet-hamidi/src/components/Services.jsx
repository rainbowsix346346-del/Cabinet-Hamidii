import { SERVICES } from '../data/services.js';

/** لیست خدمات. */
export default function Services() {
  return (
    <section id="services" className="services-section">
      <div className="container">
        <div className="sec-head reveal-item">
          <div className="sec-label">دامنه خدمات</div>
          <h2 className="sec-title">سازه‌های ام‌دی‌اف و دکوراسیون سفارشی</h2>
        </div>
        <div className="services-list">
          {SERVICES.map((s) => (
            <div key={s.id} className="service-row reveal-item">
              <span className="service-num">{s.num}</span>
              <h3 className="service-name">{s.title}</h3>
              <p className="service-desc">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
