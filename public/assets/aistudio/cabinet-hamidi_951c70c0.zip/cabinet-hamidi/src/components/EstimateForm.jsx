import { useEffect, useId, useRef, useState } from 'react';
import { SERVICES } from '../data/services.js';
import { FORM_COOLDOWN_MS } from '../config/business.js';
import { normalizePhone, isValidMobile } from '../utils/phone.js';
import { sanitizeText } from '../utils/sanitize.js';
import { submitForm } from '../utils/submitForm.js';

const INITIAL = { name: '', phone: '', serviceId: SERVICES[0].id, neighborhood: '', description: '', website: '' };

/** فرم درخواست برآورد (اعتبارسنجی، honeypot، cooldown، ارسال با stub). */
export default function EstimateForm() {
  const uid = useId();
  const [data, setData] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | submitting | success | error
  const [result, setResult] = useState(null);
  const lastSubmitRef = useRef(0);
  const abortRef = useRef(null);

  useEffect(() => () => abortRef.current?.abort(), []);

  const set = (key) => (e) => setData((d) => ({ ...d, [key]: e.target.value }));
  const id = (k) => `${uid}-${k}`;

  const validate = (clean) => {
    const err = {};
    if (!clean.name) err.name = 'لطفاً نام خود را وارد کنید.';
    if (!clean.phone) err.phone = 'شماره تماس الزامی است.';
    else if (!isValidMobile(clean.phone)) err.phone = 'شماره همراه باید ۱۱ رقم و با ۰۹ شروع شود.';
    if (!clean.neighborhood) err.neighborhood = 'نام محله یا منطقه در اهواز را وارد کنید.';
    return err;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (status === 'submitting') return;

    // honeypot: ربات‌ها این فیلد را پر می‌کنند؛ بی‌سروصدا نادیده می‌گیریم
    if (data.website) { setStatus('success'); setResult({ ...INITIAL }); return; }

    const clean = {
      name: sanitizeText(data.name, 80),
      phone: normalizePhone(sanitizeText(data.phone, 20)),
      serviceId: SERVICES.some((s) => s.id === data.serviceId) ? data.serviceId : SERVICES[0].id,
      neighborhood: sanitizeText(data.neighborhood, 80),
      description: sanitizeText(data.description, 500),
    };
    const errs = validate(clean);
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const wait = FORM_COOLDOWN_MS - (Date.now() - lastSubmitRef.current);
    if (wait > 0) {
      setErrors({ form: `لطفاً ${Math.ceil(wait / 1000)} ثانیه دیگر دوباره تلاش کنید.` });
      return;
    }

    setStatus('submitting');
    abortRef.current = new AbortController();
    try {
      await submitForm(clean, abortRef.current.signal);
      lastSubmitRef.current = Date.now();
      setResult(clean);
      setStatus('success');
    } catch (err) {
      setErrors({
        form: err?.name === 'AbortError'
          ? 'زمان ارسال به پایان رسید. دوباره تلاش کنید.'
          : 'ارسال انجام نشد. لطفاً دوباره تلاش کنید.',
      });
      setStatus('error');
    }
  };

  const serviceTitle = (sid) => SERVICES.find((s) => s.id === sid)?.title ?? '';
  const submitting = status === 'submitting';

  return (
    <div className="form-card reveal-item">
      <div className="sec-label">استعلام اولیه</div>
      <h3 className="block-title">درخواست بررسی و برآورد قیمت</h3>

      {status === 'success' && result ? (
        <div className="form-preview" role="status">
          <p className="preview-title">پیش‌نمایش مشخصات ثبت‌شده:</p>
          <p>نام: {result.name}</p>
          <p>تماس: {result.phone}</p>
          <p>خدمت: {serviceTitle(result.serviceId)}</p>
          <p>محدوده: {result.neighborhood}</p>
          {result.description && <p>توضیحات: {result.description}</p>}
          <p className="form-note">این فرم هنوز به سرور وصل نیست و اطلاعات ارسال نمی‌شود.</p>
          <button
            type="button"
            className="btn btn-outline"
            onClick={() => { setStatus('idle'); setData({ ...INITIAL, ...result }); }}
          >
            ویرایش مجدد
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label htmlFor={id('name')}>نام و نام‌خانوادگی</label>
            <input
              id={id('name')} type="text" className="form-input" value={data.name} onChange={set('name')}
              placeholder="مثال: محمد رضایی" maxLength={80} autoComplete="name"
              aria-invalid={!!errors.name} aria-describedby={errors.name ? id('name-err') : undefined}
            />
            {errors.name && <div id={id('name-err')} className="error-msg" role="alert">{errors.name}</div>}
          </div>

          <div className="form-group">
            <label htmlFor={id('phone')}>شماره تلفن همراه</label>
            <input
              id={id('phone')} type="tel" inputMode="numeric" className="form-input" value={data.phone} onChange={set('phone')}
              placeholder="۰۹۱۲۳۴۵۶۷۸۹" maxLength={20} autoComplete="tel" dir="ltr"
              aria-invalid={!!errors.phone} aria-describedby={errors.phone ? id('phone-err') : undefined}
            />
            {errors.phone && <div id={id('phone-err')} className="error-msg" role="alert">{errors.phone}</div>}
          </div>

          <div className="form-group">
            <label htmlFor={id('service')}>نوع خدمت مورد نیاز</label>
            <select id={id('service')} className="form-input" value={data.serviceId} onChange={set('serviceId')}>
              {SERVICES.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor={id('hood')}>محدوده پروژه در اهواز</label>
            <input
              id={id('hood')} type="text" className="form-input" value={data.neighborhood} onChange={set('neighborhood')}
              placeholder="مثال: کیانپارس، زیتون، گلستان..." maxLength={80} autoComplete="off"
              aria-invalid={!!errors.neighborhood} aria-describedby={errors.neighborhood ? id('hood-err') : undefined}
            />
            {errors.neighborhood && <div id={id('hood-err')} className="error-msg" role="alert">{errors.neighborhood}</div>}
          </div>

          <div className="form-group">
            <label htmlFor={id('desc')}>توضیحات (اختیاری)</label>
            <textarea
              id={id('desc')} className="form-input" rows={3} value={data.description} onChange={set('description')}
              maxLength={500} autoComplete="off"
            />
          </div>

          {/* honeypot: برای کاربر واقعی نامرئی است */}
          <div className="hp-field" aria-hidden="true">
            <label htmlFor={id('web')}>وب‌سایت</label>
            <input id={id('web')} type="text" tabIndex={-1} autoComplete="off" value={data.website} onChange={set('website')} />
          </div>

          {errors.form && <div className="error-msg" role="alert">{errors.form}</div>}

          <button type="submit" className="btn btn-solid btn-block" disabled={submitting}>
            {submitting ? 'در حال ثبت...' : 'ثبت درخواست برآورد'}
          </button>
          <div className="form-note">فرم در حال حاضر به‌صورت پیش‌نمایش در مرورگر اجرا می‌شود.</div>
        </form>
      )}
    </div>
  );
}
