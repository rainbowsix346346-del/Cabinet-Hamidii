import SafeImage from './SafeImage.jsx';
import { INSPIRATION_ITEMS } from '../data/inspiration.js';

function Card({ item, featured }) {
  return (
    <figure className={`gallery-card reveal-item ${featured ? 'featured' : ''}`}>
      <SafeImage src={item.img} alt={item.title} width={featured ? 900 : 800} height={featured ? 700 : 450} />
      <figcaption className="gallery-card-info">
        <div className="gallery-card-title">{item.title}</div>
        <div className="gallery-card-desc">{item.desc}</div>
      </figcaption>
    </figure>
  );
}

/** گالری ایده‌های طراحی (کارت اول بزرگ، بقیه ستون کناری). */
export default function Inspiration() {
  const [featured, ...rest] = INSPIRATION_ITEMS;
  return (
    <section id="inspiration" className="gallery-section">
      <div className="container">
        <div className="sec-head reveal-item">
          <div className="sec-label">ایده‌های طراحی</div>
          <h2 className="sec-title">ایده‌هایی برای طراحی کابینت و دکوراسیون</h2>
        </div>
        <div className="gallery-disclaimer reveal-item">
          تصاویر این بخش صرفاً برای الهام گرفتن از سبک‌های طراحی هستند و نمونه‌کار اختصاصی کابینت حمیدی محسوب نمی‌شوند.
        </div>
        <div className="gallery-editorial-grid">
          <Card item={featured} featured />
          {rest.map((item) => <Card key={item.id} item={item} />)}
        </div>
      </div>
    </section>
  );
}
