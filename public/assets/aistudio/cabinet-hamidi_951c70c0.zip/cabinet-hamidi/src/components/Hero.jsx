import SafeImage from './SafeImage.jsx';
import { HERO_IMAGE } from '../data/inspiration.js';

/**
 * بخش اصلی بالای صفحه.
 * @param {{onPhoneAction:()=>void}} props
 */
export default function Hero({ onPhoneAction }) {
  return (
    <section className="hero-section">
      <div className="container hero-grid">
        <div className="hero-content reveal-item">
          <div className="hero-eyebrow">طراحی و اجرای سفارشی در اهواز و خوزستان</div>
          <h1 className="hero-title">کابینت‌های مهندسی‌شده، متناسب با ابعاد دقیق خانه شما</h1>
          <p className="hero-desc">
            اندازه‌گیری حضوری، مشاوره متریال مقاوم در برابر شرایط جوی خوزستان و نصب دقیق انواع کابینت و کمد دیواری بدون واسطه.
          </p>
          <div className="hero-actions">
            <a href="#estimate" className="btn btn-solid">ثبت درخواست برآورد</a>
            <button type="button" onClick={onPhoneAction} className="btn btn-outline">تماس مستقیم</button>
          </div>
        </div>
        <div className="hero-img-wrap reveal-item">
          <SafeImage src={HERO_IMAGE.src} alt={HERO_IMAGE.alt} width={900} height={600} eager className="hero-img" />
          <span className="img-inspiration-tag">تصویر الهام‌بخش طراحی</span>
        </div>
      </div>
    </section>
  );
}
