import { useCallback } from 'react';
import { BUSINESS_CONFIG } from '../config/business.js';
import { useEscapeKey } from '../hooks/useEscapeKey.js';

const LINKS = [
  { href: '#services', label: 'خدمات' },
  { href: '#inspiration', label: 'ایده‌ها' },
  { href: '#steps', label: 'مراحل سفارش' },
  { href: '#estimate', label: 'استعلام قیمت' },
];

/**
 * هدر سایت + منوی موبایل.
 * @param {{menuOpen:boolean, onToggleMenu:()=>void, onCloseMenu:()=>void}} props
 */
export default function Header({ menuOpen, onToggleMenu, onCloseMenu }) {
  const close = useCallback(() => onCloseMenu(), [onCloseMenu]);
  useEscapeKey(menuOpen, close);

  return (
    <header className="site-header">
      <div className="container header-inner">
        <div>
          <span className="brand-logo">{BUSINESS_CONFIG.brandName}</span>
          <span className="brand-tag">{BUSINESS_CONFIG.city}</span>
        </div>

        <nav className="nav-desktop" aria-label="منوی اصلی">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} className="nav-link">{l.label}</a>
          ))}
        </nav>

        <div className="header-actions">
          <a href="#estimate" className="btn btn-solid">درخواست برآورد</a>
          <button
            type="button"
            className="hamburger-btn"
            onClick={onToggleMenu}
            aria-label={menuOpen ? 'بستن منو' : 'باز کردن منو'}
            aria-expanded={menuOpen}
            aria-controls="mobile-drawer"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              {menuOpen ? <path d="M18 6L6 18M6 6l12 12" /> : <path d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>

      <nav id="mobile-drawer" className={`mobile-drawer ${menuOpen ? 'open' : ''}`} aria-label="منوی موبایل">
        {LINKS.map((l) => (
          <a key={l.href} href={l.href} className="nav-link" onClick={onCloseMenu}>{l.label}</a>
        ))}
      </nav>
    </header>
  );
}
