import { ORDER_STEPS } from '../data/steps.js';

/** مراحل اجرای سفارش. */
export default function Steps() {
  return (
    <section id="steps" className="steps-section">
      <div className="container">
        <div className="sec-head reveal-item">
          <div className="sec-label sec-label-light">فرآیند همکاری</div>
          <h2 className="sec-title sec-title-light">مراحل اجرای سفارش</h2>
        </div>
        <div className="steps-grid">
          {ORDER_STEPS.map((st) => (
            <div key={st.num} className="step-item reveal-item">
              <div className="step-index">{st.num}</div>
              <h3 className="step-name">{st.title}</h3>
              <p className="step-desc">{st.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
